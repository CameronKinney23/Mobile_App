package com.example.cameronkinneyprojectthree;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cameronkinneyprojectthree.database.DatabaseHelper;

public class RegisterActivity extends AppCompatActivity {

    private EditText editTextUsername, editTextPassword;
    private DatabaseHelper databaseHelper;
    private Button buttonRegister; // Declare globally to avoid scope issues

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Initialize UI elements
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonRegister = findViewById(R.id.buttonRegister);
        databaseHelper = new DatabaseHelper(this);

        // Debugging: Confirm DatabaseHelper is initialized
        if (databaseHelper == null) {
            Log.e("RegisterActivity", "DatabaseHelper is null! Registration cannot proceed.");
            return; // Exit early if there's an issue
        }

        // Handle register button click
        buttonRegister.setOnClickListener(v -> {
            String username = editTextUsername.getText().toString().trim();
            String password = editTextPassword.getText().toString().trim();

            Log.d("RegisterActivity", "Register button clicked!");

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                Log.w("RegisterActivity", "User left a field empty");
            } else {
                try {
                    Log.d("RegisterActivity", "Attempting to register user: " + username);
                    boolean success = databaseHelper.registerUser(username, password);
                    Log.d("RegisterActivity", "Registration result: " + success);

                    if (success) {
                        Toast.makeText(RegisterActivity.this, "Registration successful!", Toast.LENGTH_SHORT).show();
                        Log.i("RegisterActivity", "User registered: " + username);

                        // Navigate to LoginActivity
                        Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                        startActivity(intent);
                        finish(); // Close RegisterActivity
                    } else {
                        Toast.makeText(RegisterActivity.this, "Username already exists!", Toast.LENGTH_SHORT).show();
                        Log.w("RegisterActivity", "Registration failed: username already exists.");
                    }
                } catch (Exception e) {
                    Log.e("RegisterActivity", "Error registering user", e);
                    Toast.makeText(RegisterActivity.this, "Error registering user, please try again", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
