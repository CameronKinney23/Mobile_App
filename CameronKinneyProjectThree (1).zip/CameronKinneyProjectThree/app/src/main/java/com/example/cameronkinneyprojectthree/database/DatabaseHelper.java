package com.example.cameronkinneyprojectthree.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database constants
    private static final String DATABASE_NAME = "InventoryApp.db";
    private static final int DATABASE_VERSION = 3; // Bumped to 3 to apply table changes

    // User table constants
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Inventory table constants
    public static final String TABLE_INVENTORY = "inventory";
    public static final String COL_ITEM_ID = "id";
    public static final String COL_ITEM_NAME = "item_name";
    public static final String COL_LOCATION = "location";
    public static final String COL_QUANTITY = "quantity";

    // Notifications table constants
    public static final String TABLE_NOTIFICATIONS = "notifications";
    public static final String COL_NOTIFICATION_ID = "id";
    public static final String COL_MESSAGE = "message";

    // SQL statement to create the users table
    private static final String CREATE_USERS_TABLE =
            "CREATE TABLE " + TABLE_USERS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USERNAME + " TEXT UNIQUE, " +
                    COLUMN_PASSWORD + " TEXT NOT NULL);";

    // SQL to create inventory table
    private static final String CREATE_INVENTORY_TABLE =
            "CREATE TABLE " + TABLE_INVENTORY + " (" +
                    COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_ITEM_NAME + " TEXT, " +
                    COL_LOCATION + " TEXT, " +
                    COL_QUANTITY + " INTEGER);";

    // SQL to create notifications table
    private static final String CREATE_NOTIFICATIONS_TABLE =
            "CREATE TABLE " + TABLE_NOTIFICATIONS + " (" +
                    COL_NOTIFICATION_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_MESSAGE + " TEXT);";

    // Constructor
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Create the database tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USERS_TABLE);
        db.execSQL(CREATE_INVENTORY_TABLE);
        db.execSQL(CREATE_NOTIFICATIONS_TABLE);
    }

    // Upgrade database if needed
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NOTIFICATIONS);
        onCreate(db);
    }

    // Method to register a new user
    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result != -1;
    }

    // Method to validate login credentials
    public boolean checkUserCredentials(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_USERS + " WHERE " +
                COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username, password});
        boolean userExists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return userExists;
    }

    // Insert new item from user input
    public boolean insertInventoryItem(String name, String location, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_LOCATION, location);
        values.put(COL_QUANTITY, quantity);
        long result = db.insert(TABLE_INVENTORY, null, values);
        db.close();
        return result != -1;
    }

    // Fetch all inventory items
    public Cursor getAllInventoryItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_INVENTORY, null);
    }

    // === NEW: Update inventory item quantity
    public boolean updateInventoryQuantity(int itemId, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_QUANTITY, newQuantity);
        int rowsAffected = db.update(TABLE_INVENTORY, values, COL_ITEM_ID + " = ?", new String[]{String.valueOf(itemId)});
        db.close();
        return rowsAffected > 0;
    }

    // === NEW: Delete inventory item by ID
    public boolean deleteInventoryItem(int itemId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete(TABLE_INVENTORY, COL_ITEM_ID + " = ?", new String[]{String.valueOf(itemId)});
        db.close();
        return rowsDeleted > 0;
    }

    // === NEW: Insert a notification
    public void insertNotification(String message) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_MESSAGE, message);
        db.insert(TABLE_NOTIFICATIONS, null, values);
        db.close();
    }

    // === NEW: Get all notifications
    public ArrayList<String> getAllNotifications() {
        ArrayList<String> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NOTIFICATIONS + " ORDER BY " + COL_NOTIFICATION_ID + " DESC", null);

        if (cursor.moveToFirst()) {
            do {
                String msg = cursor.getString(cursor.getColumnIndexOrThrow(COL_MESSAGE));
                list.add(msg);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return list;
    }

    // === NEW: Clear notifications
    public void clearNotifications() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NOTIFICATIONS, null, null);
        db.close();
    }
}
