package com.example.cameronkinneyprojectthree;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.cameronkinneyprojectthree.database.DatabaseHelper;

public class InventoryActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    private EditText editTextItemName, editTextLocation, editTextQuantity;
    private Button buttonAddItem, buttonViewNotifications;
    private TableLayout inventoryTable;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        editTextItemName = findViewById(R.id.editTextItemName);
        editTextLocation = findViewById(R.id.editTextLocation);
        editTextQuantity = findViewById(R.id.editTextQuantity);
        buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonViewNotifications = findViewById(R.id.buttonViewNotifications);
        inventoryTable = findViewById(R.id.inventoryTable);
        databaseHelper = new DatabaseHelper(this);

        buttonAddItem.setOnClickListener(v -> {
            String itemName = editTextItemName.getText().toString().trim();
            String location = editTextLocation.getText().toString().trim();
            String quantityStr = editTextQuantity.getText().toString().trim();

            if (itemName.isEmpty() || location.isEmpty() || quantityStr.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity;
            try {
                quantity = Integer.parseInt(quantityStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean inserted = insertInventoryItem(itemName, location, quantity);

            if (inserted) {
                Toast.makeText(this, "Item added!", Toast.LENGTH_SHORT).show();
                editTextItemName.setText("");
                editTextLocation.setText("");
                editTextQuantity.setText("");
                refreshTable();
            } else {
                Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
            }
        });

        buttonViewNotifications.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, NotificationActivity.class);
            startActivity(intent);
        });

        refreshTable();
    }

    private boolean insertInventoryItem(String name, String location, int quantity) {
        boolean success = databaseHelper.insertInventoryItem(name, location, quantity);

        if (success) {
            String addedMsg = "✅ Added: " + name + " (Qty: " + quantity + ")";
            databaseHelper.insertNotification(addedMsg);

            if (quantity <= 3) {
                String warningMsg = "⚠️ Low Stock: " + name + " (" + quantity + ")";
                databaseHelper.insertNotification(warningMsg);
                sendLowStockSMS(warningMsg);
            }
        }

        return success;
    }

    private void sendLowStockSMS(String message) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage("5554", null, message, null, null);
                Toast.makeText(this, "Low stock SMS sent", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void refreshTable() {
        inventoryTable.removeAllViews();

        TableRow headerRow = new TableRow(this);
        String[] headers = {"Item", "Location", "Qty", "Delete"};
        for (String title : headers) {
            TextView header = new TextView(this);
            header.setText(title);
            header.setPadding(16, 16, 16, 16);
            header.setTextSize(18);
            headerRow.addView(header);
        }
        inventoryTable.addView(headerRow);

        Cursor cursor = databaseHelper.getAllInventoryItems();

        if (cursor.moveToFirst()) {
            do {
                TableRow row = new TableRow(this);

                int itemId = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_ID));
                String itemName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_NAME));
                String location = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_LOCATION));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_QUANTITY));

                TextView itemCell = new TextView(this);
                itemCell.setText(itemName);
                itemCell.setPadding(16, 8, 16, 8);

                TextView locationCell = new TextView(this);
                locationCell.setText(location);
                locationCell.setPadding(16, 8, 16, 8);

                TextView quantityCell = new TextView(this);
                quantityCell.setText(String.valueOf(quantity));
                quantityCell.setPadding(16, 8, 16, 8);

                Button deleteButton = new Button(this);
                deleteButton.setText("Delete");
                deleteButton.setOnClickListener(v -> {
                    boolean deleted = databaseHelper.deleteInventoryItem(itemId);
                    if (deleted) {
                        Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
                        refreshTable();
                    } else {
                        Toast.makeText(this, "Failed to delete", Toast.LENGTH_SHORT).show();
                    }
                });

                row.addView(itemCell);
                row.addView(locationCell);
                row.addView(quantityCell);
                row.addView(deleteButton);

                inventoryTable.addView(row);
            } while (cursor.moveToNext());
        }

        cursor.close();
    }
}