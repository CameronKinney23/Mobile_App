package com.example.cameronkinneyprojectthree;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cameronkinneyprojectthree.database.DatabaseHelper;

import java.util.ArrayList;

public class NotificationActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> notifications;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        // Link UI
        ListView listViewNotifications = findViewById(R.id.listViewNotifications);
        Button buttonClear = findViewById(R.id.buttonClearNotifications);

        dbHelper = new DatabaseHelper(this);

        // Load notifications from database
        notifications = dbHelper.getAllNotifications();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, notifications);
        listViewNotifications.setAdapter(adapter);

        // Handle clear button
        buttonClear.setOnClickListener(v -> {
            dbHelper.clearNotifications();
            notifications.clear();
            adapter.notifyDataSetChanged();
            Toast.makeText(this, "Notifications cleared", Toast.LENGTH_SHORT).show();
        });
    }
}